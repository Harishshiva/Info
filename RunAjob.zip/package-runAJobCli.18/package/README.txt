Please refer to the below link for latest documentation on runAJobCli utility

https://docs.informatica.com/integration-cloud/cloud-platform/current-version/rest-api-reference/data-integration-rest-api/runajob-utility.html